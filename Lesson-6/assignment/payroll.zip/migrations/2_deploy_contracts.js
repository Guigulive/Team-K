var SimpleStorage = artifacts.require("./SimpleStorage.sol");
var SafeMath = artifacts.require("./SafeMath.sol");
var Ownalbe = artifacts.require("./Ownable.sol");
var Payroll = artifacts.require("./Payroll.sol");

module.exports = function(deployer) {
  deployer.deploy(SimpleStorage);

  deployer.deploy(SafeMath);
  deployer.deploy(Ownalbe);

  deployer.link(SafeMath, Payroll);
  deployer.link(Ownalbe, Payroll);

  deployer.deploy(Payroll);
};
