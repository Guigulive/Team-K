## 硅谷live以太坊智能合约频道官方地址

### 第五课

目录结构
  <br/>|
  <br/>|--orgin 课程初始代码
  <br/>|
  <br/>|--assignment 课程作业提交代码
<br/> 

### 本节知识点

/metamask.io/)
1. Run `testrpc`
1. Add first account in testrpc to Metamask by importing private key
1. Run `truffle compile` in the project directory
1. `truffle migrate`
1. `npm run start`
